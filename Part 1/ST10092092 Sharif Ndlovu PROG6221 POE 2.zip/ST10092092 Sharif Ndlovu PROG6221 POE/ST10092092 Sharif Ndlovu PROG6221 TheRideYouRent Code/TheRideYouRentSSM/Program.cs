﻿using System;
using System.Globalization;

namespace TheRideYouRent
{

    public interface IExpenses // interface 
    {
        double CalculateMonthlyRepayment(); // interface method
    }

    public class GeneralExpenses : IExpenses
    {
        private double groceries, waterAndElectricity, travelCost, cellPhoneBill, monthlyRepayment;

        // constructor
        public GeneralExpenses(double groceries, double waterAndElectricity, double travelCost, double cellPhoneBill)
        {
            SetGroceries(groceries);
            SetCellPhoneBill(cellPhoneBill);
            SetTravelCost(travelCost);
            SetWaterAndElectricity(waterAndElectricity);
        }

        // getters and setters
        public void SetGroceries(double groceries)
        {
            this.groceries = groceries;
        }

        public void SetWaterAndElectricity(double waterAndElectricity)
        {
            this.waterAndElectricity = waterAndElectricity;
        }

        public void SetTravelCost(double travelCost)
        {
            this.travelCost = travelCost;
        }

        public void SetCellPhoneBill(double cellPhoneBill)
        {
            this.cellPhoneBill = cellPhoneBill;
        }

        // overriden method from Expenses
        public double CalculateMonthlyRepayment()
        {
            monthlyRepayment = groceries + waterAndElectricity + travelCost + cellPhoneBill;
            return monthlyRepayment;
        }
    }

    public class HomeLoan : IExpenses
    {
        private double propertyPrice, deposit, monthlyRepayment, amountRemainingToPay, tempResult;
        private int monthsToPay, interestRate;
        private bool RedLoanAlert;

        // constructor
        public HomeLoan(double propertyPrice, double deposit, int interestRate, int monthsToPay)
        {
            SetPropertyPrice(propertyPrice);
            SetDeposit(deposit);
            SetMonthsToPay(monthsToPay);
            SetInterestRate(interestRate);
        }

        public double GetHomeLoanRepayment()
        {
            return monthlyRepayment;
        }

        // overriden method from Expenses interface
        public double CalculateMonthlyRepayment()
        {
            amountRemainingToPay = propertyPrice - deposit;

            tempResult = amountRemainingToPay * (1 + interestRate / 100 * monthsToPay);

            monthlyRepayment = tempResult / monthsToPay;
            return monthlyRepayment;
        }

        // check if student can afford the loan
        public bool CheckForAlert()
        {

            double income = Income.GetIncomeAfterTax();
            double priceCeiling = income / 3;

            if (monthlyRepayment > priceCeiling)
            {
                RedLoanAlert = true;
            }
            else
            {
                RedLoanAlert = false;
            }
            return RedLoanAlert;
        }

        // getters and setters
        public double GetPropertyPrice()
        {
            return propertyPrice;
        }

        public double GetDeposit()
        {
            return deposit;
        }

        public int GetInterestRate()
        {
            return interestRate;
        }

        public int GetMonthsToPay()
        {
            return monthsToPay;
        }

        public void SetPropertyPrice(double propertyPrice)
        {
            this.propertyPrice = propertyPrice;
        }

        public void SetDeposit(double deposit)
        {
            this.deposit = deposit;
        }

        public void SetInterestRate(int interestRate)
        {
            this.interestRate = interestRate;
        }

        public void SetMonthsToPay(int monthsToPay)
        {
            this.monthsToPay = monthsToPay;
        }
    }

    public class Income
    {
        private static double monthlyIncome, taxDeduction;

        // constructor
        public Income(double monthlyIncome, double taxDeduction)
        {
            SetMonthlyIncome(monthlyIncome);
            SetTaxDeduction(taxDeduction);
        }


        public static double GetIncomeAfterTax()
        {
            return monthlyIncome - taxDeduction;
        }

        // getters and setters
        public void SetMonthlyIncome(double monthlyIncome)
        {
            Income.monthlyIncome = monthlyIncome;
        }

        public void SetTaxDeduction(double taxDeduction)
        {
            Income.taxDeduction = taxDeduction;
        }

        public double GetTaxDeduction()
        {
            return taxDeduction;
        }

        public double GetMonthlyIncome()
        {
            return monthlyIncome;
        }

    }

    public class PrintSheet
    {
        public static double moneyAvailable, tempGroceries, tempWaterAndElectricity, tempTravelCost, tempCellPhone, tempPropertyPrice, tempDeposit, tempRent;
        public static double tempIncome, tempDeduction;
        public static int accommodationSelection, tempMonthlyRepayment, tempInterestRate;
        public static bool alert;
        public static bool flag = true;

        // gather input required to begin processing
        public static void CollectValues()
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("*******************************************************");
                    Console.WriteLine("Please provide your amounts for the following...");
                    Console.WriteLine("Monthly Income (Before Tax) :");
                    tempIncome = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Tax Reduction :");
                    tempDeduction = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("*******************************************************");
                    Console.WriteLine("Please provide your expense costs for the following...");
                    Console.WriteLine("Groceries : ");
                    tempGroceries = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Water & Electricity : ");
                    tempWaterAndElectricity = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Travel Cost (inc Petrol) : ");
                    tempTravelCost = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Cell/Telephone Bill : ");
                    tempCellPhone = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine();
                    break;
                }
                catch (Exception e) // catch input errors
                {
                    Console.WriteLine("ERROR: " + e + "\nRefreshing...\n");
                }
            }


            while (flag)
            {
                while (true)
                {
                    try
                    {
                        Console.WriteLine("Please provide the number for your preferred accommodation...");
                        Console.WriteLine("Renting (1) or Buying a Home (2)");
                        accommodationSelection = Convert.ToInt16(Console.ReadLine());
                        break;

                    }
                    catch (Exception e) // catch input errors
                    {
                        Console.WriteLine("ERROR: " + e + "\nRefreshing...\n");
                    }
                }


                switch (accommodationSelection)
                {
                    case 1:
                        Console.WriteLine("You have selected Renting...");
                        RentSelection();
                        flag = false;
                        break;

                    case 2:
                        Console.WriteLine("You have selected Buying a Home...");
                        HomeLoanSelection();
                        flag = false;
                        break;

                    default:
                        Console.WriteLine("Incorrect input please try again (1 or 2)\n");
                        flag = true;
                        break;
                }
            }
        }

        public static void RentSelection()
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("Please provide the cost of your rent..");
                    Console.WriteLine("Rent : ");
                    tempRent = Convert.ToDouble(Console.ReadLine());
                    break;

                }
                catch (Exception e) // catch input errors
                {
                    Console.WriteLine("ERROR: " + e + "\nRefreshing...\n");
                }
            }

            // create objects and provide the user's input
            Renting re = new Renting(tempRent);
            GeneralExpenses ge = new GeneralExpenses(tempGroceries, tempWaterAndElectricity, tempTravelCost, tempCellPhone);
            Income inc = new Income(tempIncome, tempDeduction);

            moneyAvailable = Income.GetIncomeAfterTax() - re.rentCost - ge.CalculateMonthlyRepayment();
            PrintResult(ge.CalculateMonthlyRepayment(), re.rentCost);
        }

        public static void HomeLoanSelection()
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("\nBeginning Home Loan Calculation");
                    Console.WriteLine("Please provide the amounts of the following...");
                    Console.WriteLine("Property Price : ");
                    tempPropertyPrice = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Initial Deposit : ");
                    tempDeposit = Convert.ToInt16(Console.ReadLine());
                    Console.WriteLine("Interest rate");
                    tempInterestRate = Convert.ToInt16(Console.ReadLine());

                    flag = true;
                    while (true)
                    {
                        Console.WriteLine("Number of Months to pay (240-360):");
                        tempMonthlyRepayment = Convert.ToInt16(Console.ReadLine());

                        if ((tempMonthlyRepayment >= 240) && (tempMonthlyRepayment <= 360))
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("\nNumber of months should be limited in between 240 - 360..");
                            Console.WriteLine("Please provide the amounts of the following...");
                        }
                    }

                    break;

                }
                catch (Exception e) // catch input errors
                {
                    Console.WriteLine("ERROR: " + e + "\nRefreshing...\n");
                }
            }

            // create objects and provide the user's input
            Income inc = new Income(tempIncome, tempDeduction);
            GeneralExpenses ge = new GeneralExpenses(tempGroceries, tempWaterAndElectricity, tempTravelCost, tempCellPhone);
            HomeLoan hl = new HomeLoan(tempPropertyPrice, tempDeposit, tempInterestRate, tempMonthlyRepayment);

            if (hl.CheckForAlert() == true)
            {
                Console.WriteLine("Your application for a home loan will likely be unsuccessful due to the monthly installments being more than a third of your salary");
            }

            moneyAvailable = Income.GetIncomeAfterTax() - ge.CalculateMonthlyRepayment() - hl.GetHomeLoanRepayment();
            PrintResult(ge.CalculateMonthlyRepayment(), hl.CalculateMonthlyRepayment(), hl.CheckForAlert());

        }

        public static void StoreExpensesIntoArray(double housing)
        {
            string[] expenseNames = { "Groceries", "Electricity & Water", "Travel Costs", "CellPhone", "Rent/House" };
            double[] expenses = { tempGroceries, tempWaterAndElectricity, tempTravelCost, tempCellPhone, housing };

            Console.WriteLine("Would you like to view your expenses? Enter (1) for Yes or any other key for No");
            string selection = Console.ReadLine();

            if (selection.Equals("1"))
            {
                for (int x = 0; x < 5; x++)
                {
                    Console.WriteLine(expenseNames[x] + ": " + expenses[x].ToString("C", CultureInfo.CurrentCulture));
                }
            }
            Console.ReadKey();
        }

        // display renting option
        public static void PrintResult(double generalExpenses, double accommodationExpenses)
        {

            double tempExpense = generalExpenses + accommodationExpenses;

            Console.WriteLine("*********************************************************");
            Console.WriteLine("Monthly Income (After Tax): " + tempIncome.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("*********************************************************");
            Console.WriteLine("Monthly Expenses : " + tempExpense.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("**********************");
            Console.WriteLine("General Expenses : " + tempExpense.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("Accommodation Expenses : " + accommodationExpenses.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            Console.WriteLine("Money Remaining After Expenses : " + moneyAvailable.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            Console.Read();

            StoreExpensesIntoArray(accommodationExpenses);
        }

        // display buying home option
        public static void PrintResult(double generalExpenses, double homeRepayment, bool flag)
        {

            double tempRemainingOwed = tempPropertyPrice - tempDeposit;

            Console.WriteLine("*********************************************************");
            Console.WriteLine("Property Price : " + tempPropertyPrice.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("Deposit : " + tempDeposit.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("Amount after deposit : " + tempRemainingOwed.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("Interest Rate : " + tempInterestRate + "%");
            Console.WriteLine("Months to Pay : " + tempMonthlyRepayment);
            Console.WriteLine("Monthly Repayment For Home Loan : " + homeRepayment.ToString("C", CultureInfo.CurrentCulture));

            if (flag == true)
            {
                Console.WriteLine("REMINDER, Your application for a home loan will likely be unsuccessful due to the monthly installments being more than a third of your salary");
            }
            else
            {
                Console.WriteLine("Your application for a home loan will most likely be successful due to the monthly installments being less than or equal to a third of your salary");
            }

            Console.WriteLine("Your Income : " + Income.GetIncomeAfterTax().ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("Loan Repayment : " + homeRepayment.ToString("C", CultureInfo.CurrentCulture));

            Console.WriteLine("*********************************************************");
            Console.WriteLine("");

            double tempExpense = generalExpenses + homeRepayment;
            Console.WriteLine("*********************************************************");
            Console.WriteLine("Monthly Income (After Tax): " + Income.GetIncomeAfterTax().ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("*********************************************************");
            Console.WriteLine("Monthly Expenses : " + tempExpense.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("**********************");
            Console.WriteLine("General Expenses : " + generalExpenses.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("Monthly Home Repayment : " + homeRepayment.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            Console.WriteLine("Money Remaining After Expenses : " + moneyAvailable.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            Console.Read();

            StoreExpensesIntoArray(homeRepayment);
        }
    }

    public class Renting : IExpenses
    {
        public double rentCost;

        // constructor
        public Renting(double rentCost)
        {
            SetRentCost(rentCost);
        }

        // overridden method from expenses interfaces
        public double CalculateMonthlyRepayment()
        {
            return rentCost;
        }

        // setter for Rent Cost
        public void SetRentCost(double rentCost)
        {
            this.rentCost = rentCost;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            PrintSheet.CollectValues(); // call method to begin
        }
    }
}